import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../models/task_model.dart';
import '../utils/theme.dart';

class TaskCard extends StatelessWidget {
  final TaskModel task;
  final VoidCallback? onTap;
  final VoidCallback? onToggle;
  final VoidCallback? onDelete;
  final bool showCheckbox;

  const TaskCard({
    super.key,
    required this.task,
    this.onTap,
    this.onToggle,
    this.onDelete,
    this.showCheckbox = true,
  });

  @override
  Widget build(BuildContext context) {
    final categoryColor =
        AppTheme.categoryColors[task.category] ?? AppTheme.primaryColor;
    final categoryIcon =
        AppTheme.categoryIcons[task.category] ?? Icons.task_rounded;

    return Dismissible(
      key: Key(task.id),
      direction: DismissDirection.endToStart,
      onDismissed: (_) => onDelete?.call(),
      background: Container(
        alignment: Alignment.centerRight,
        padding: const EdgeInsets.only(right: 24),
        decoration: BoxDecoration(
          color: AppTheme.error.withValues(alpha: 0.1),
          borderRadius: BorderRadius.circular(AppTheme.radiusLarge),
        ),
        child: const Icon(Icons.delete_rounded, color: AppTheme.error, size: 28),
      ),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeInOut,
        margin: const EdgeInsets.only(bottom: 12),
        decoration: BoxDecoration(
          color: task.isCompleted
              ? AppTheme.cardColor.withValues(alpha: 0.6)
              : AppTheme.surfaceColor,
          borderRadius: BorderRadius.circular(AppTheme.radiusLarge),
          boxShadow: task.isCompleted ? [] : AppTheme.cardShadow,
          border: task.isOverdue
              ? Border.all(color: AppTheme.error.withValues(alpha: 0.3), width: 1.5)
              : null,
        ),
        child: Material(
          color: Colors.transparent,
          child: InkWell(
            onTap: onTap,
            borderRadius: BorderRadius.circular(AppTheme.radiusLarge),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Row(
                children: [
                  // Category indicator
                  Container(
                    width: 44,
                    height: 44,
                    decoration: BoxDecoration(
                      color: categoryColor.withValues(alpha: 0.12),
                      borderRadius:
                          BorderRadius.circular(AppTheme.radiusMedium),
                    ),
                    child: Icon(
                      categoryIcon,
                      color: categoryColor,
                      size: 22,
                    ),
                  ),
                  const SizedBox(width: 14),

                  // Task info
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          task.title,
                          style: TextStyle(
                            fontSize: 15,
                            fontWeight: FontWeight.w600,
                            color: task.isCompleted
                                ? AppTheme.textHint
                                : AppTheme.textPrimary,
                            decoration: task.isCompleted
                                ? TextDecoration.lineThrough
                                : null,
                          ),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                        if (task.subtitle.isNotEmpty) ...[
                          const SizedBox(height: 3),
                          Text(
                            task.subtitle,
                            style: TextStyle(
                              fontSize: 12,
                              color: AppTheme.textHint,
                              decoration: task.isCompleted
                                  ? TextDecoration.lineThrough
                                  : null,
                            ),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ],
                        const SizedBox(height: 6),
                        Row(
                          children: [
                            if (task.dueTime != null) ...[
                              Icon(
                                Icons.access_time_rounded,
                                size: 13,
                                color: task.isOverdue
                                    ? AppTheme.error
                                    : AppTheme.textHint,
                              ),
                              const SizedBox(width: 4),
                              Text(
                                _formatTime(task.dueTime!),
                                style: TextStyle(
                                  fontSize: 11,
                                  fontWeight: FontWeight.w500,
                                  color: task.isOverdue
                                      ? AppTheme.error
                                      : AppTheme.textHint,
                                ),
                              ),
                              const SizedBox(width: 12),
                            ],
                            if (task.hasLocation) ...[
                              const Icon(
                                Icons.location_on_rounded,
                                size: 13,
                                color: AppTheme.primaryLight,
                              ),
                              const SizedBox(width: 4),
                              Flexible(
                                child: Text(
                                  task.locationLabel ?? 'Location',
                                  style: const TextStyle(
                                    fontSize: 11,
                                    fontWeight: FontWeight.w500,
                                    color: AppTheme.primaryLight,
                                  ),
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                ),
                              ),
                            ],
                            if (task.isOverdue) ...[
                              Container(
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 6, vertical: 2),
                                decoration: BoxDecoration(
                                  color: AppTheme.error.withValues(alpha: 0.1),
                                  borderRadius: BorderRadius.circular(4),
                                ),
                                child: const Text(
                                  'Overdue',
                                  style: TextStyle(
                                    fontSize: 10,
                                    fontWeight: FontWeight.w600,
                                    color: AppTheme.error,
                                  ),
                                ),
                              ),
                            ],
                          ],
                        ),
                      ],
                    ),
                  ),

                  // Checkbox
                  if (showCheckbox)
                    GestureDetector(
                      onTap: onToggle,
                      child: AnimatedContainer(
                        duration: const Duration(milliseconds: 300),
                        width: 28,
                        height: 28,
                        decoration: BoxDecoration(
                          color: task.isCompleted
                              ? AppTheme.success
                              : Colors.transparent,
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(
                            color: task.isCompleted
                                ? AppTheme.success
                                : AppTheme.textHint.withValues(alpha: 0.3),
                            width: 2,
                          ),
                        ),
                        child: task.isCompleted
                            ? const Icon(Icons.check_rounded,
                                color: Colors.white, size: 18)
                            : null,
                      ),
                    ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  String _formatTime(DateTime time) {
    final now = DateTime.now();
    final diff = time.difference(now);

    if (task.isCompleted) {
      return DateFormat('MMM d, h:mm a').format(time);
    }

    if (diff.isNegative) {
      if (diff.inMinutes.abs() < 60) {
        return '${diff.inMinutes.abs()}m overdue';
      }
      if (diff.inHours.abs() < 24) {
        return '${diff.inHours.abs()}h overdue';
      }
      return DateFormat('MMM d').format(time);
    }

    if (diff.inMinutes < 60) {
      return 'In ${diff.inMinutes}m';
    }
    if (diff.inHours < 24) {
      return 'In ${diff.inHours}h ${diff.inMinutes % 60}m';
    }
    return DateFormat('MMM d, h:mm a').format(time);
  }
}
