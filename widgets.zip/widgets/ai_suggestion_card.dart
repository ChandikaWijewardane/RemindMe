import 'package:flutter/material.dart';
import '../utils/theme.dart';

class AiSuggestionCard extends StatelessWidget {
  final String title;
  final String subtitle;
  final String iconType;
  final VoidCallback? onTap;
  final VoidCallback? onDismiss;

  const AiSuggestionCard({
    super.key,
    required this.title,
    required this.subtitle,
    this.iconType = 'reminder',
    this.onTap,
    this.onDismiss,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            _getGradientStart().withValues(alpha: 0.08),
            _getGradientEnd().withValues(alpha: 0.04),
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(AppTheme.radiusLarge),
        border: Border.all(
          color: _getIconColor().withValues(alpha: 0.15),
          width: 1,
        ),
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(AppTheme.radiusLarge),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Row(
              children: [
                // Icon
                Container(
                  width: 48,
                  height: 48,
                  decoration: BoxDecoration(
                    color: _getIconColor().withValues(alpha: 0.15),
                    borderRadius:
                        BorderRadius.circular(AppTheme.radiusMedium),
                  ),
                  child: Icon(
                    _getIcon(),
                    color: _getIconColor(),
                    size: 24,
                  ),
                ),
                const SizedBox(width: 14),

                // Text
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        title,
                        style: const TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w600,
                          color: AppTheme.textPrimary,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        subtitle,
                        style: const TextStyle(
                          fontSize: 12,
                          color: AppTheme.textSecondary,
                        ),
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ],
                  ),
                ),

                // Dismiss
                if (onDismiss != null)
                  IconButton(
                    onPressed: onDismiss,
                    icon: Icon(
                      Icons.close_rounded,
                      size: 18,
                      color: AppTheme.textHint.withValues(alpha: 0.5),
                    ),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  IconData _getIcon() {
    switch (iconType) {
      case 'shopping':
        return Icons.shopping_bag_rounded;
      case 'health':
        return Icons.favorite_rounded;
      case 'social':
        return Icons.people_rounded;
      case 'work':
        return Icons.work_rounded;
      case 'reminder':
      default:
        return Icons.lightbulb_rounded;
    }
  }

  Color _getIconColor() {
    switch (iconType) {
      case 'shopping':
        return AppTheme.categoryColors['shopping']!;
      case 'health':
        return AppTheme.categoryColors['health']!;
      case 'social':
        return AppTheme.categoryColors['social']!;
      case 'work':
        return AppTheme.categoryColors['work']!;
      case 'reminder':
      default:
        return AppTheme.primaryColor;
    }
  }

  Color _getGradientStart() {
    return _getIconColor();
  }

  Color _getGradientEnd() {
    return _getIconColor().withValues(alpha: 0.5);
  }
}
