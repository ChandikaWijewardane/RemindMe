import 'package:flutter_local_notifications/flutter_local_notifications.dart';

class NotificationService {
  static final NotificationService _instance = NotificationService._();
  factory NotificationService() => _instance;
  NotificationService._();

  final FlutterLocalNotificationsPlugin _plugin = FlutterLocalNotificationsPlugin();
  bool _initialized = false;

  Future<void> initialize() async {
    if (_initialized) return;

    const androidSettings = AndroidInitializationSettings('@mipmap/ic_launcher');
    const iosSettings = DarwinInitializationSettings(
      requestAlertPermission: true,
      requestBadgePermission: true,
      requestSoundPermission: true,
    );

    const settings = InitializationSettings(android: androidSettings, iOS: iosSettings);
    await _plugin.initialize(settings, onDidReceiveNotificationResponse: _onNotificationTapped);
    _initialized = true;
  }

  Future<bool> requestPermissions() async {
    final androidPlugin = _plugin.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
    if (androidPlugin != null) {
      final granted = await androidPlugin.requestNotificationsPermission();
      return granted ?? false;
    }
    return true;
  }

  Future<void> showNotification({required int id, required String title, required String body, String? payload}) async {
    const androidDetails = AndroidNotificationDetails(
      'remindme_channel', 'RemindMe Notifications',
      channelDescription: 'Task reminders and AI suggestions',
      importance: Importance.high, priority: Priority.high, showWhen: true,
    );
    const iosDetails = DarwinNotificationDetails(presentAlert: true, presentBadge: true, presentSound: true);
    const details = NotificationDetails(android: androidDetails, iOS: iosDetails);
    await _plugin.show(id, title, body, details, payload: payload);
  }

  Future<void> showGeofenceNotification({required String taskTitle, required String locationLabel}) async {
    await showNotification(id: DateTime.now().millisecondsSinceEpoch ~/ 1000, title: '📍 Location Reminder', body: "You're near $locationLabel — don't forget: $taskTitle");
  }

  Future<void> showTaskReminder({required String taskTitle, required String timeInfo}) async {
    await showNotification(id: DateTime.now().millisecondsSinceEpoch ~/ 1000, title: '⏰ Task Reminder', body: '$taskTitle — $timeInfo');
  }

  Future<void> showAiSuggestion({required String suggestion}) async {
    await showNotification(id: DateTime.now().millisecondsSinceEpoch ~/ 1000, title: '💡 AI Suggestion', body: suggestion);
  }

  Future<void> cancelNotification(int id) async => await _plugin.cancel(id);
  Future<void> cancelAll() async => await _plugin.cancelAll();

  void _onNotificationTapped(NotificationResponse response) {
    // Navigation can be handled via a global key or callback
  }
}
