import 'dart:async';
import 'dart:math';
import 'package:geolocator/geolocator.dart';
import '../models/task_model.dart';
import '../utils/constants.dart';

class LocationService {
  StreamSubscription<Position>? _positionSubscription;
  Function(TaskModel task)? onGeofenceTriggered;

  // Check and request permissions
  Future<bool> checkPermissions() async {
    bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      return false;
    }

    LocationPermission permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) {
        return false;
      }
    }

    if (permission == LocationPermission.deniedForever) {
      return false;
    }

    return true;
  }

  // Get current position
  Future<Position?> getCurrentPosition() async {
    final hasPermission = await checkPermissions();
    if (!hasPermission) return null;

    return await Geolocator.getCurrentPosition(
      locationSettings: const LocationSettings(
        accuracy: LocationAccuracy.high,
      ),
    );
  }

  // Start monitoring location for geofencing
  void startGeofenceMonitoring(
    List<TaskModel> locationTasks,
    Function(TaskModel) onTriggered,
  ) {
    onGeofenceTriggered = onTriggered;
    _positionSubscription?.cancel();

    _positionSubscription = Geolocator.getPositionStream(
      locationSettings: const LocationSettings(
        accuracy: LocationAccuracy.high,
        distanceFilter: 100, // Update every 100 meters
      ),
    ).listen((Position position) {
      _checkGeofences(position, locationTasks);
    });
  }

  // Check if user is within any geofence
  void _checkGeofences(Position position, List<TaskModel> tasks) {
    for (final task in tasks) {
      if (task.hasLocation && !task.isCompleted) {
        final distance = _calculateDistance(
          position.latitude,
          position.longitude,
          task.lat!,
          task.lng!,
        );

        if (distance <= (task.radius ?? AppConstants.geofenceRadius)) {
          onGeofenceTriggered?.call(task);
        }
      }
    }
  }

  // Calculate distance between two points (Haversine formula)
  double _calculateDistance(
      double lat1, double lon1, double lat2, double lon2) {
    const double earthRadius = 6371000; // meters
    final double dLat = _degreesToRadians(lat2 - lat1);
    final double dLon = _degreesToRadians(lon2 - lon1);

    final double a = sin(dLat / 2) * sin(dLat / 2) +
        cos(_degreesToRadians(lat1)) *
            cos(_degreesToRadians(lat2)) *
            sin(dLon / 2) *
            sin(dLon / 2);
    final double c = 2 * atan2(sqrt(a), sqrt(1 - a));

    return earthRadius * c;
  }

  double _degreesToRadians(double degrees) {
    return degrees * pi / 180;
  }

  // Stop monitoring
  void stopMonitoring() {
    _positionSubscription?.cancel();
    _positionSubscription = null;
  }

  // Dispose
  void dispose() {
    stopMonitoring();
  }
}
