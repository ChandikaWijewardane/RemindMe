import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/task_model.dart';
import '../models/user_model.dart';

class FirestoreService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  // ─── TASKS ─────────────────────────────────────────────

  // Get tasks collection reference
  CollectionReference _tasksRef(String uid) =>
      _firestore.collection('users').doc(uid).collection('tasks');

  // Add task
  Future<String> addTask(String uid, TaskModel task) async {
    final docRef = await _tasksRef(uid).add(task.toFirestore());
    // Update total tasks count
    await _incrementTotalTasks(uid);
    return docRef.id;
  }

  // Update task
  Future<void> updateTask(String uid, TaskModel task) async {
    await _tasksRef(uid).doc(task.id).update(task.toFirestore());
  }

  // Delete task
  Future<void> deleteTask(String uid, String taskId) async {
    await _tasksRef(uid).doc(taskId).delete();
  }

  // Toggle task completion
  Future<void> toggleTaskCompletion(
      String uid, String taskId, bool isCompleted) async {
    await _tasksRef(uid).doc(taskId).update({
      'isCompleted': isCompleted,
      'completedAt': isCompleted ? FieldValue.serverTimestamp() : null,
    });

    if (isCompleted) {
      await _incrementCompletedTasks(uid);
    } else {
      await _decrementCompletedTasks(uid);
    }

    // Update focus score
    await _updateFocusScore(uid);
  }

  // Stream all tasks
  Stream<List<TaskModel>> streamAllTasks(String uid) {
    return _tasksRef(uid)
        .orderBy('createdAt', descending: true)
        .snapshots()
        .map((snapshot) =>
            snapshot.docs.map((doc) => TaskModel.fromFirestore(doc)).toList());
  }

  // Stream today's tasks
  Stream<List<TaskModel>> streamTodayTasks(String uid) {
    final now = DateTime.now();
    final startOfDay = DateTime(now.year, now.month, now.day);
    final endOfDay = startOfDay.add(const Duration(days: 1));

    return _tasksRef(uid)
        .where('dueTime',
            isGreaterThanOrEqualTo: Timestamp.fromDate(startOfDay))
        .where('dueTime', isLessThan: Timestamp.fromDate(endOfDay))
        .snapshots()
        .map((snapshot) =>
            snapshot.docs.map((doc) => TaskModel.fromFirestore(doc)).toList());
  }

  // Stream completed tasks (history)
  Stream<List<TaskModel>> streamCompletedTasks(String uid) {
    return _tasksRef(uid)
        .where('isCompleted', isEqualTo: true)
        .orderBy('completedAt', descending: true)
        .snapshots()
        .map((snapshot) =>
            snapshot.docs.map((doc) => TaskModel.fromFirestore(doc)).toList());
  }

  // Stream location-based tasks
  Stream<List<TaskModel>> streamLocationTasks(String uid) {
    return _tasksRef(uid)
        .where('lat', isNull: false)
        .snapshots()
        .map((snapshot) => snapshot.docs
            .map((doc) => TaskModel.fromFirestore(doc))
            .where((task) => !task.isCompleted)
            .toList());
  }

  // Stream flagged tasks (overdue)
  Stream<List<TaskModel>> streamFlaggedTasks(String uid) {
    return _tasksRef(uid)
        .where('isCompleted', isEqualTo: false)
        .where('dueTime', isLessThan: Timestamp.fromDate(DateTime.now()))
        .snapshots()
        .map((snapshot) =>
            snapshot.docs.map((doc) => TaskModel.fromFirestore(doc)).toList());
  }

  // Get task history for AI suggestions
  Future<List<TaskModel>> getRecentTaskHistory(String uid,
      {int limit = 50}) async {
    final snapshot = await _tasksRef(uid)
        .orderBy('createdAt', descending: true)
        .limit(limit)
        .get();
    return snapshot.docs.map((doc) => TaskModel.fromFirestore(doc)).toList();
  }

  // ─── USER ──────────────────────────────────────────────

  // Get user document
  Stream<UserModel?> streamUser(String uid) {
    return _firestore.collection('users').doc(uid).snapshots().map(
        (doc) => doc.exists ? UserModel.fromFirestore(doc) : null);
  }

  // Update user profile
  Future<void> updateUserProfile(
      String uid, Map<String, dynamic> data) async {
    await _firestore.collection('users').doc(uid).update(data);
  }

  // ─── STATS ─────────────────────────────────────────────

  Future<void> _incrementTotalTasks(String uid) async {
    await _firestore.collection('users').doc(uid).update({
      'totalTasksToday': FieldValue.increment(1),
    });
  }

  Future<void> _incrementCompletedTasks(String uid) async {
    await _firestore.collection('users').doc(uid).update({
      'tasksCompletedToday': FieldValue.increment(1),
    });
  }

  Future<void> _decrementCompletedTasks(String uid) async {
    await _firestore.collection('users').doc(uid).update({
      'tasksCompletedToday': FieldValue.increment(-1),
    });
  }

  Future<void> _updateFocusScore(String uid) async {
    final doc = await _firestore.collection('users').doc(uid).get();
    if (doc.exists) {
      final data = doc.data()!;
      final total = data['totalTasksToday'] ?? 0;
      final completed = data['tasksCompletedToday'] ?? 0;
      final score = total > 0 ? (completed / total) * 100 : 0.0;
      await _firestore.collection('users').doc(uid).update({
        'focusScore': score,
      });
    }
  }

  // Reset daily stats (call at midnight or on app open)
  Future<void> resetDailyStats(String uid) async {
    await _firestore.collection('users').doc(uid).update({
      'tasksCompletedToday': 0,
      'totalTasksToday': 0,
    });
  }

  // ─── SETTINGS ──────────────────────────────────────────

  // Save settings to Firestore
  Future<void> saveSettings(
      String uid, Map<String, dynamic> settings) async {
    await _firestore
        .collection('users')
        .doc(uid)
        .collection('settings')
        .doc('preferences')
        .set(settings, SetOptions(merge: true));
  }

  // Get settings
  Future<Map<String, dynamic>?> getSettings(String uid) async {
    final doc = await _firestore
        .collection('users')
        .doc(uid)
        .collection('settings')
        .doc('preferences')
        .get();
    return doc.exists ? doc.data() : null;
  }
}
