import 'dart:convert';
import 'package:http/http.dart' as http;
import '../utils/constants.dart';

class ChatMessage {
  final String text;
  final bool isUser;
  final DateTime timestamp;
  final Map<String, dynamic>? taskData;

  ChatMessage({
    required this.text,
    required this.isUser,
    required this.timestamp,
    this.taskData,
  });
}

class AiService {
  final List<Map<String, dynamic>> _conversationHistory = [];

  // Send message to Gemini API
  Future<ChatMessage> sendMessage(String userMessage) async {
    // Add user message to history
    _conversationHistory.add({
      'role': 'user',
      'parts': [
        {'text': userMessage}
      ],
    });

    try {
      final response = await http.post(
        Uri.parse(
            '${AppConstants.geminiEndpoint}?key=${AppConstants.geminiApiKey}'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'contents': [
            {
              'role': 'user',
              'parts': [
                {'text': AppConstants.aiSystemPrompt}
              ],
            },
            ..._conversationHistory,
          ],
          'generationConfig': {
            'temperature': 0.7,
            'topK': 40,
            'topP': 0.95,
            'maxOutputTokens': 1024,
          },
        }),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        final aiText =
            data['candidates'][0]['content']['parts'][0]['text'] as String;

        // Add AI response to history
        _conversationHistory.add({
          'role': 'model',
          'parts': [
            {'text': aiText}
          ],
        });

        // Parse task data if present
        Map<String, dynamic>? taskData;
        final taskMatch =
            RegExp(r'\[TASK_JSON\](.*?)\[/TASK_JSON\]', dotAll: true)
                .firstMatch(aiText);
        if (taskMatch != null) {
          try {
            taskData = jsonDecode(taskMatch.group(1)!);
          } catch (_) {}
        }

        // Clean display text
        String displayText =
            aiText.replaceAll(RegExp(r'\[TASK_JSON\].*?\[/TASK_JSON\]', dotAll: true), '').trim();

        return ChatMessage(
          text: displayText,
          isUser: false,
          timestamp: DateTime.now(),
          taskData: taskData,
        );
      } else {
        throw Exception('API error: ${response.statusCode} - ${response.body}');
      }
    } catch (e) {
      return ChatMessage(
        text:
            "I'm having trouble connecting right now. Please check your internet connection and try again! 🔄",
        isUser: false,
        timestamp: DateTime.now(),
      );
    }
  }

  // Get AI suggestions based on task history
  Future<List<Map<String, dynamic>>> getSuggestions(
      List<Map<String, dynamic>> taskHistory) async {
    try {
      final prompt = '''
${AppConstants.suggestionPrompt}

User's recent task history:
${jsonEncode(taskHistory)}

Current time: ${DateTime.now().toIso8601String()}
Day of week: ${_getDayName(DateTime.now().weekday)}
''';

      final response = await http.post(
        Uri.parse(
            '${AppConstants.geminiEndpoint}?key=${AppConstants.geminiApiKey}'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'contents': [
            {
              'role': 'user',
              'parts': [
                {'text': prompt}
              ],
            },
          ],
          'generationConfig': {
            'temperature': 0.8,
            'maxOutputTokens': 1024,
          },
        }),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        final aiText =
            data['candidates'][0]['content']['parts'][0]['text'] as String;

        // Extract JSON array from response
        final jsonMatch =
            RegExp(r'\[.*\]', dotAll: true).firstMatch(aiText);
        if (jsonMatch != null) {
          final suggestions =
              jsonDecode(jsonMatch.group(0)!) as List<dynamic>;
          return suggestions.cast<Map<String, dynamic>>();
        }
      }
    } catch (e) {
      // Return default suggestions on error
    }

    return _getDefaultSuggestions();
  }

  // Default suggestions when API is unavailable
  List<Map<String, dynamic>> _getDefaultSuggestions() {
    return [
      {
        'title': 'Time for a break! 🧘',
        'subtitle':
            "You've been active for a while. A 5-minute break can boost focus.",
        'icon': 'health',
      },
      {
        'title': 'Review your tasks 📋',
        'subtitle':
            'Check your upcoming tasks and prioritize what matters most.',
        'icon': 'work',
      },
      {
        'title': 'Stay hydrated! 💧',
        'subtitle':
            "Don't forget to drink water. Hydration helps concentration.",
        'icon': 'health',
      },
      {
        'title': 'Connect with someone 📱',
        'subtitle':
            'A quick call to a friend or family member can brighten your day.',
        'icon': 'social',
      },
    ];
  }

  String _getDayName(int weekday) {
    const days = [
      'Monday',
      'Tuesday',
      'Wednesday',
      'Thursday',
      'Friday',
      'Saturday',
      'Sunday'
    ];
    return days[weekday - 1];
  }

  // Clear conversation history
  void clearHistory() {
    _conversationHistory.clear();
  }
}
